<?php
namespace app\model;

use think\Model;

class Base extends Model
{

}